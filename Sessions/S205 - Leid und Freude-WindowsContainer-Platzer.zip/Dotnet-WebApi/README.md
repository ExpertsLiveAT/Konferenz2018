# Docker Windows Container Example Windowsservercore
This is a Web App that can be deployed in a Windows Docker Container.

# Author
Franz Platzer