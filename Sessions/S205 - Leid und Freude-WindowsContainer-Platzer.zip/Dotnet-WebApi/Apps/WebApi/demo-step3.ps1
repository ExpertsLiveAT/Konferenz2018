echo "docker build -t experts/demo-webapi --build-arg CERTIFICATE_PASSWORD=expertslive ."
docker build -t experts/demo-webapi --build-arg CERTIFICATE_PASSWORD=expertslive .