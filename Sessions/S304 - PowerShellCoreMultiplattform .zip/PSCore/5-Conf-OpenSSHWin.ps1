# C:\Program Files\Openssh\sshd_config_default is just a template
$sshdLoc = 'C:\ProgramData\ssh'
set-location $sshdLoc 
# How to fix SSH timeout

# Create a Symbolic Link to a easy-2-read-dir
$linkdir = 'c:\pwsh'
$ps6dir = 'C:\Program Files\PowerShell\6'

New-Item -Path $linkdir -ItemType SymbolicLink -Value $ps6dir

code $sshdLoc\sshd_config

# Restart SSH Services
Get-Service ssh* |restart-service

