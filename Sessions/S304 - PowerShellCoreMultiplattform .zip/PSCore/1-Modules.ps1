# Module aus dem Windows Moduleverzeichnis ==> PS Code Compatibel
get-module -ListAvailable |Where-Object CompanyName -like 'Microsoft*'`
    |where-object path -like 'C:\WINDOWS\system32\WindowsPowerShell\v1.0*'`
    |Select-Object Name, CompatiblePSEditions

