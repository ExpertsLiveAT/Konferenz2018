# Really on PS Core ?
$psversionTable.psedition

#Connect to 4 Platforms
$steve = New-PSSession -hostname 'steve' -UserName 'user'
$bill = New-PSSession -hostname 'bill' -UserName 'domain\user'
$linus = New-PSSession -hostname 'linus' -UserName 'user'
$pi = New-PSSession -hostname 'pi' -UserName 'user'

# Multiplatform Array
$servers = $steve, $bill, $linus, $pi

# Uptime report
$Servers |ForEach-Object {Invoke-command -Session $_ -ScriptBlock `
     {get-uptime} }|select-object PSComputername, Days, Hours, Minutes

#Available Drives
$Servers |ForEach-Object {Invoke-command -Session $_ -ScriptBlock `
    {Get-PSDrive -PSProvider FileSystem} }`
    |select-object Root, Used, PSComputername |Format-Table -AutoSize

# Its all one object type !
$d = $Servers |ForEach-Object {Invoke-command -Session $_ -ScriptBlock `
    {Get-PSDrive -PSProvider FileSystem} }
$d.Name
$d.Provider
#Module Differences
$Servers |ForEach-Object {Invoke-command -Session $_ -ScriptBlock `
    {Get-Module -Listavailable} }|Select-Object PSComputerName,Name -Unique|group PSComputername -NoElement


