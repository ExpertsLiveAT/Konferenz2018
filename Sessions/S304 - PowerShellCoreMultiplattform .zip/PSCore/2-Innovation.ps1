# Neue features
$w = Invoke-restMethod -Uri https://api.github.com/repos/powershell/powershell/issues
$w.name.count

$w = Invoke-restMethod -Uri https://api.github.com/repos/powershell/powershell/issues `
    -FollowRelLink -MaximumFollowRelLink 5
$w.name.count

# Push-Location / Pop Location
Set-Location -
# Auto-expanding properties
Get-Process|select-object -ExpandProperty 

# JSON

