Write-Host "*** Prepare variables"
$openssh = 'https://github.com/PowerShell/Win32-OpenSSH/releases/download/v7.7.2.0p1-Beta/OpenSSH-Win64.zip'
$dlfile = 'c:\temp\openssh.zip'
$instfolder = 'C:\Program Files\OpenSSH'


Write-Host "*** Create Target Folder"
New-Item -Type Directory -Path $instfolder
Test-Path $instfolder

Write-Host "*** Download and extract to correct folder"
invoke-webrequest $openssh -OutFile $dlfile
Expand-Archive c:\temp\openssh.zip -DestinationPath C:\temp\
Get-ChildItem .\OpenSSH-Win64\ -Recurse|ForEach-Object {Move-Item $PSItem -Destination $instfolder}

# identify version on https://github.com/PowerShell/Win32-OpenSSH/releases/latest
set-location $instfolder
$instfolder\install-sshd.ps1

# WinServer/win10 
New-NetFirewallRule -Name sshd -DisplayName 'OpenSSH Server (sshd)' -Enabled True -Direction Inbound -Protocol TCP -Action Allow -LocalPort 22
