# Update Help
update-help -Module Microsoft.Powershell* -force

# Where -Not Operator (für [boolean])
get-service|Where-Object -Not Dependentservices|Select-Object name, DependentServices

#Path Leafbase and Extension
$p = "$pshome\powershell.exe"
Split-Path $p
Split-Path $p -Parent
Split-Path $p -Leaf
# Neu in PSCore
Split-Path $p -extension
Split-Path $p -Leafbase

# Convertto-JSON differences

# Unwrap arrays
ConvertTo-JSON ([PSObject](,1))


