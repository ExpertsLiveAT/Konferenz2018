# Thanks Richard Siddaway for this!

#PowerShell v6.1 preview 4 brings a Measure-Object enhancement.
#Measure-Object has been around since PowerShell v1. It enables you to measure the properties of an object and easily perform a number of calculations.
Get-ChildItem -File | Measure-Object -Property Length

#The original calculations were – Count, Sum, Average, Minimum and Maximum
#Using Measure-Object was a very successful short cut in a number of solutions to scripting games puzzles over the years and was often the differentiator of those who really knew how to use PowerShell.
Get-ChildItem -File | Measure-Object -Property Length  -Average -Sum

#PowerShell v6 added the calculation to produce the standard deviation
Get-ChildItem -File | Measure-Object -Property Length  -Average -StandardDeviation

#PowerShell v6.1 preview 4 adds the –Allstats parameter so that you get get all of the calculations done in one pass
Get-ChildItem -File | Measure-Object -Property Length -AllStats
